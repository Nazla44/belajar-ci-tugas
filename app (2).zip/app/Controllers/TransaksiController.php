<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\Responseinterface;

class TransaksiController extends BaseController
{
    public function index()
    {
        return view('v_keranjang');
    }
}